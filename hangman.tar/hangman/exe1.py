#!/opt/rh/rh-python36/root/usr/bin/python

#def main():
#    # Call the function func
#
#if __name__ == "__main__":
#    main()




#file_path = "/home/ps/hangman/words.txt"

#def choose_word(file_path, index):
#    with open(file_path, "r") as input_file:
#        words = input_file.read()
#        num_of_words = (len(set(words.split())))
#        out_tuple = (num_of_words, words[index])
#        print (out_tuple)
#
# NEED TO FIX THIS FUNC, PRINT THE WORD IN INDEX VALUE EXE 9.4.1
#
#choose_word(file_path, 2)



HANGMAN_ASCII_ART = """
      _	   _
     | |  | |  
     | |__| | __ _ _ __   __ _ _ __ ___   __ _ _ __  
     |  __  |/ _` | '_ \ / _` | '_ ` _ \ / _` | '_ \ 
     | |  | | (_| | | | | (_| | | | | | | (_| | | | |
     |_|  |_|\__,_|_| |_|\__, |_| |_| |_|\__,_|_| |_|
                          __/ |                      
                         |___/
"""
print (HANGMAN_ASCII_ART)
MAX_TRIES = 6
print (MAX_TRIES)


def check_valid_input(letter_guessed, old_letters_guessed):
    if (len(letter_guessed) == 1) and letter_guessed.isalpha() and (letter_guessed not in old_letters_guessed):
        return True
    else:
        return False

def try_update_letter_guessed(letter_guessed, old_letters_guessed):
    if check_valid_input(letter_guessed, old_letters_guessed):
        old_letters_guessed.append(letter_guessed)
        return True
    else:
        print('X')
        old_letters_guessed.sort()
        updated_str_old_letters_guessed = " -> ".join(old_letters_guessed)
        print(updated_str_old_letters_guessed.lower())
        return False

def show_hidden_word(secret_word, old_letters_guessed):
    word = ""
    for i in secret_word:
        if i in old_letters_guessed:
            word = word + " " +(i)
        else:
            word = word + " _"
    return word

def check_win(secret_word, old_letters_guessed):
    for i in secret_word:
        if i in old_letters_guessed:
            return True
        else:
            return False






HANGMAN_PHOTOS = {
    '0':  """
    x-------x""",

    '1': """
    x-------x
    |
    |
    |
    |
    |""",
 
    '2': """
    x-------x
    |       |
    |       0
    |
    |
    |
	""",

    '3': """
    x-------x
    |       |
    |       0 
    |       |
    |
    |
	""",
    
    '4': """
    x-------x
    |       |
    |       0
    |      /|\\
    |
    |
	""",

    '5': """
    x-------x
    |       |
    |       0
    |      /|\\
    |      / 
    |	
	""",

    '6': """
    x-------x
    |       |
    |       0
    |      /|\\
    |      / \\
    |
	""",
}

def print_hangman(num_of_tries):
    print(HANGMAN_PHOTOS[str(num_of_tries)])


# ----------------------------------------------

num_of_tries = 0
secret_word = "mammals"
old_letters_guessed = []
print('Let’s start!')
print_hangman(num_of_tries)
print("_ " * len(secret_word))

letter_guessed = input("Guess a letter: ")
old_letters_guessed = ['s', 'p', 'j', 'i', 'm', 'k']
try_update_letter_guessed(letter_guessed, old_letters_guessed)

